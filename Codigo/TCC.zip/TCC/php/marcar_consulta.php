<?php
session_start();
include 'conexao.php';

if (!isset($_SESSION['usuario_id'])) {
    die("Erro: Usuário não autenticado. Faça login para continuar.");
}

$usuario_id = $_SESSION['usuario_id'];
$unidade_id = intval($_POST['unidade_id'] ?? 0);
$especialidade_id = intval($_POST["especialidade_id"] ?? 0);
$data_hora = $_POST['data_hora'] ?? '';

function sanitize($data) {
    return htmlspecialchars(trim($data));
}

// Validações
if ($unidade_id <= 0 || $especialidade_id <= 0 || empty($data_hora)) {
    die("Erro: Campos obrigatórios (unidade, especialidade, data/hora) não preenchidos.");
}
if (!DateTime::createFromFormat('Y-m-d H:i:s', $data_hora)) {
    die("Erro: Formato de data inválido. Use o formato YYYY-MM-DD HH:mm:ss.");
}

// Verifica se a consulta já existe
$stmt = $conexao->prepare("SELECT id FROM consultas WHERE unidade_id = ? AND data_hora = ?");
$stmt->bind_param("is", $unidade_id, $data_hora);
$stmt->execute();
if ($stmt->get_result()->num_rows > 0) {
    die("Erro: Horário já reservado.");
}
$stmt->close();

// Insere a consulta
$stmt = $conexao->prepare("INSERT INTO consultas (usuario_id, unidade_id, especialidade_id, data_hora, status) VALUES (?, ?, ?, ?, 'Agendada')");
$stmt->bind_param("iiis", $usuario_id, $unidade_id, $especialidade_id, $data_hora);

if ($stmt->execute()) {
    echo "Consulta marcada com sucesso!";
} else {
    echo "Erro ao marcar consulta no banco de dados.";
}

$stmt->close();
$conexao->close();
?>