<?php
include 'conexao.php';

function sanitize($data) {
    return htmlspecialchars(trim($data));
}

$nome = sanitize($_POST['nome'] ?? '');
$cpf = sanitize($_POST['cpf'] ?? '');
$data_nascimento = $_POST['data_nascimento'] ?? '';
$telefone = sanitize($_POST['telefone'] ?? '');
$email = sanitize($_POST['email'] ?? '');
$senha = $_POST['senha'] ?? '';
$endereco = sanitize($_POST['endereco'] ?? '');

// Validações
if (empty($nome) || empty($cpf) || empty($data_nascimento) || empty($email) || empty($senha)) {
    die("Erro: Campos obrigatórios (nome, CPF, data de nascimento, e-mail, senha) não preenchidos.");
}
if (!preg_match('/^\d{3}\.\d{3}\.\d{3}-\d{2}$/', $cpf)) {
    die("Erro: CPF inválido. Use o formato 123.456.789-00.");
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    die("Erro: E-mail inválido.");
}
if (strlen($senha) < 6) {
    die("Erro: Senha deve ter no mínimo 6 caracteres.");
}

// Mapear endereço (exemplo simples, pode ser ajustado)
$cep = '00000-000';
$numero = '123';
$complemento = '';
$cidade = 'Piraquara';

// Verifica unicidade
$stmt = $conexao->prepare("SELECT id FROM usuarios WHERE cpf = ? OR email = ?");
$stmt->bind_param("ss", $cpf, $email);
$stmt->execute();
if ($stmt->get_result()->num_rows > 0) {
    die("Erro: CPF ou e-mail já cadastrado.");
}
$stmt->close();

// Hash da senha
$senha_hash = password_hash($senha, PASSWORD_DEFAULT);

// Insere com prepared statement
$stmt = $conexao->prepare("INSERT INTO usuarios (nome, cpf, data_nascimento, telefone, email, senha, cep, numero, complemento, cidade) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("ssssssssss", $nome, $cpf, $data_nascimento, $telefone, $email, $senha_hash, $cep, $numero, $complemento, $cidade);

if ($stmt->execute()) {
    echo "Cadastro realizado com sucesso!";
} else {
    echo "Erro ao cadastrar no banco de dados.";
}

$stmt->close();
$conexao->close();
?>