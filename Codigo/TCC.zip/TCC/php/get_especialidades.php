<?php
include 'conexao.php';

header('Content-Type: application/json');

$sql = "SELECT id, nome FROM especialidades ORDER BY nome ASC";
$result = $conexao->query($sql);

$especialidades = [];
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $especialidades[] = $row;
    }
}

echo json_encode($especialidades);

$conexao->close();
?>

