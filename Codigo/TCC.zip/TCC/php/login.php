<?php
session_start();
include 'conexao.php';

$email = $_POST['email'] ?? '';
$senha = $_POST['senha'] ?? '';

if (empty($email) || empty($senha)) {
    die("Erro: Preencha e-mail e senha.");
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    die("Erro: E-mail inválido.");
}

// Verifica o usuário
$stmt = $conexao->prepare("SELECT id, nome, senha FROM usuarios WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("Erro: E-mail ou senha inválidos.");
}

$user = $result->fetch_assoc();

if (password_verify($senha, $user['senha'])) {
    $_SESSION['usuario_id'] = $user['id'];
    $_SESSION['usuario_nome'] = $user['nome'];
    echo "Login realizado com sucesso!";
} else {
    die("Erro: E-mail ou senha inválidos.");
}

$stmt->close();
$conexao->close();
?>