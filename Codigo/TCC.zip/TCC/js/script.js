let currentMonth = 4; // Inicia em maio (0 = janeiro)
let currentYear = 2025;
let selectedDay = null;
let selectedTime = null;
let selectedUnidadeId = null;

function openModal() {
    document.getElementById('loginModal').style.display = 'flex';
}

function closeModal() {
    document.getElementById('loginModal').style.display = 'none';
}

function openRegisterModal() {
    document.getElementById('loginModal').style.display = 'none';
    document.getElementById('registerModal').style.display = 'flex';
}

function closeRegisterModal() {
    document.getElementById('registerModal').style.display = 'none';
}

function openForgotPasswordModal() {
    document.getElementById('loginModal').style.display = 'none';
    document.getElementById('forgotPasswordModal').style.display = 'flex';
}

function closeForgotPasswordModal() {
    document.getElementById('forgotPasswordModal').style.display = 'none';
}

function backToLogin() {
    document.getElementById('registerModal').style.display = 'none';
    document.getElementById('loginModal').style.display = 'flex';
}

function backToLoginFromForgot() {
    document.getElementById('forgotPasswordModal').style.display = 'none';
    document.getElementById('loginModal').style.display = 'flex';
}

function login() {
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;
    const mensagem = document.getElementById('loginMensagem');
    const button = document.querySelector('#loginModal button[onclick="login()"]');

    if (!email || !password) {
        mensagem.innerText = 'Preencha e-mail e senha.';
        mensagem.className = 'error';
        return;
    }

    button.disabled = true;
    button.innerText = 'Entrando...';

    const formData = new FormData();
    formData.append('email', email);
    formData.append('senha', password);

    fetch('php/login.php', {
        method: 'POST',
        body: formData
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`Erro na requisição: ${response.status} ${response.statusText}`);
        }
        return response.text();
    })
    .then(data => {
        console.log('Resposta do servidor:', data); // Depuração
        mensagem.innerText = data;
        mensagem.className = data.includes('sucesso') ? 'success' : 'error';
        button.disabled = false;
        button.innerText = 'Entrar';
        if (data.includes('sucesso')) {
            setTimeout(() => {
                closeModal();
                document.querySelector('.header h1').innerText = `Bem-vindo, ${email.split('@')[0]}!`;
            }, 1000);
        }
    })
    .catch(error => {
        mensagem.innerText = 'Erro ao realizar login. Verifique o console para detalhes.';
        mensagem.className = 'error';
        button.disabled = false;
        button.innerText = 'Entrar';
        console.error('Erro:', error);
    });
}

function loginAsProfessional() {
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;
    const mensagem = document.getElementById('loginMensagem');

    if (!email || !password) {
        mensagem.innerText = 'Preencha e-mail e senha.';
        mensagem.className = 'error';
        return;
    }

    mensagem.innerText = 'Login como profissional não implementado.';
    mensagem.className = 'error';
}

function recoverPassword() {
    const cpf = document.getElementById('forgotCpf').value;
    const email = document.getElementById('forgotEmail').value;
    const phone = document.getElementById('forgotPhone').value;
    const mensagem = document.getElementById('forgotMensagem');

    if (!cpf || !email || !phone) {
        mensagem.innerText = 'Preencha todos os campos.';
        mensagem.className = 'error';
        return;
    }

    mensagem.innerText = 'Instruções enviadas para o e-mail.';
    mensagem.className = 'success';
    setTimeout(() => {
        closeForgotPasswordModal();
        openModal();
    }, 1000);
}

document.getElementById('form-cadastro').addEventListener('submit', function (e) {
    e.preventDefault();
    const form = this;
    const cpf = form.querySelector('#registerCpf').value;
    const email = form.querySelector('#registerEmail').value;
    const senha = form.querySelector('#registerPassword').value;
    const mensagem = document.getElementById('mensagem');
    const button = form.querySelector('button[type="submit"]');

    if (!cpf.match(/^\d{3}\.\d{3}\.\d{3}-\d{2}$/)) {
        mensagem.innerText = 'CPF inválido. Use o formato 123.456.789-00.';
        mensagem.className = 'error';
        return;
    }
    if (!email.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) {
        mensagem.innerText = 'E-mail inválido.';
        mensagem.className = 'error';
        return;
    }
    if (senha.length < 6) {
        mensagem.innerText = 'Senha deve ter no mínimo 6 caracteres.';
        mensagem.className = 'error';
        return;
    }

    button.disabled = true;
    button.innerText = 'Enviando...';

    const formData = new FormData(form);

    fetch('php/cadastrar_usuario.php', {
        method: 'POST',
        body: formData
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`Erro na requisição: ${response.status} ${response.statusText}`);
        }
        return response.text();
    })
    .then(data => {
        console.log('Resposta do servidor:', data); // Depuração
        mensagem.innerText = data;
        mensagem.className = data.includes('sucesso') ? 'success' : 'error';
        button.disabled = false;
        button.innerText = 'Cadastrar';
        if (data.includes('sucesso')) {
            form.reset();
            setTimeout(() => {
                closeRegisterModal();
                openModal();
            }, 1000);
        }
    })
    .catch(error => {
        mensagem.innerText = 'Erro ao enviar os dados. Verifique o console para detalhes.';
        mensagem.className = 'error';
        button.disabled = false;
        button.innerText = 'Cadastrar';
        console.error('Erro:', error);
    });
});

function openUnitDetails(unit, id) {
    selectedUnidadeId = id;
    document.getElementById('unitTitle').innerText = `Agenda da ${unit}`;
    document.getElementById('unitDetails').style.display = 'block';
    updateCalendar();
}

function closeUnitDetails() {
    document.getElementById('unitDetails').style.display = 'none';
    selectedDay = null;
    selectedTime = null;
    selectedUnidadeId = null;
}

function openProfileEdit() {
    document.getElementById('profileEdit').style.display = 'block';
    document.getElementById('unitsSection').style.display = 'none';
    document.getElementById('recipesSection').style.display = 'none';
    document.getElementById('examsSection').style.display = 'none';
    document.getElementById('notificationsSection').style.display = 'none';
    document.getElementById('helpSection').style.display = 'none';
}

function openRecipes() {
    document.getElementById('recipesSection').style.display = 'block';
    document.getElementById('unitsSection').style.display = 'none';
    document.getElementById('profileEdit').style.display = 'none';
    document.getElementById('examsSection').style.display = 'none';
    document.getElementById('notificationsSection').style.display = 'none';
    document.getElementById('helpSection').style.display = 'none';
}

function openExams() {
    document.getElementById('examsSection').style.display = 'block';
    document.getElementById('unitsSection').style.display = 'none';
    document.getElementById('profileEdit').style.display = 'none';
    document.getElementById('recipesSection').style.display = 'none';
    document.getElementById('notificationsSection').style.display = 'none';
    document.getElementById('helpSection').style.display = 'none';
}

function openNotifications() {
    document.getElementById('notificationsSection').style.display = 'block';
    document.getElementById('unitsSection').style.display = 'none';
    document.getElementById('profileEdit').style.display = 'none';
    document.getElementById('recipesSection').style.display = 'none';
    document.getElementById('examsSection').style.display = 'none';
    document.getElementById('helpSection').style.display = 'none';
}

function openHelp() {
    document.getElementById('helpSection').style.display = 'block';
    document.getElementById('unitsSection').style.display = 'none';
    document.getElementById('profileEdit').style.display = 'none';
    document.getElementById('recipesSection').style.display = 'none';
    document.getElementById('examsSection').style.display = 'none';
    document.getElementById('notificationsSection').style.display = 'none';
}

function goToHome() {
    document.getElementById('profileEdit').style.display = 'none';
    document.getElementById('recipesSection').style.display = 'none';
    document.getElementById('examsSection').style.display = 'none';
    document.getElementById('notificationsSection').style.display = 'none';
    document.getElementById('helpSection').style.display = 'none';
    document.getElementById('unitsSection').style.display = 'block';
}

function logout() {
    if (confirm('Tem certeza que deseja sair?')) {
        document.getElementById('profileEdit').style.display = 'none';
        document.getElementById('recipesSection').style.display = 'none';
        document.getElementById('examsSection').style.display = 'none';
        document.getElementById('notificationsSection').style.display = 'none';
        document.getElementById('helpSection').style.display = 'none';
        document.getElementById('unitsSection').style.display = 'none';
        document.getElementById('loginModal').style.display = 'flex';
    }
}

function updateCalendar() {
    const monthSelect = document.getElementById('monthSelect');
    const yearSelect = document.getElementById('yearSelect');
    currentMonth = parseInt(monthSelect.value);
    currentYear = parseInt(yearSelect.value);

    const calendarBody = document.getElementById('calendarBody');
    calendarBody.innerHTML = '';

    const firstDay = new Date(currentYear, currentMonth, 1);
    const lastDay = new Date(currentYear, currentMonth + 1, 0);
    const startingDay = firstDay.getDay();
    const daysInMonth = lastDay.getDate();
    const today = new Date();
    const currentDate = new Date(currentYear, currentMonth);

    let row = document.createElement('tr');
    let dayCount = 1;

    for (let i = 0; i < startingDay; i++) {
        const cell = document.createElement('td');
        row.appendChild(cell);
    }

    for (let i = startingDay; i < 7; i++) {
        if (dayCount <= daysInMonth) {
            const cell = document.createElement('td');
            cell.textContent = dayCount;
            if (currentDate < today && dayCount < today.getDate()) {
                cell.classList.add('disabled');
            } else {
                cell.onclick = (function(day) {
                    return function() {
                        selectDay(day);
                    };
                })(dayCount);
                if (selectedDay === dayCount) {
                    cell.classList.add('selected');
                }
            }
            row.appendChild(cell);
            dayCount++;
        }
    }
    calendarBody.appendChild(row);

    while (dayCount <= daysInMonth) {
        row = document.createElement('tr');
        for (let i = 0; i < 7; i++) {
            if (dayCount <= daysInMonth) {
                const cell = document.createElement('td');
                cell.textContent = dayCount;
                if (currentDate < today && dayCount < today.getDate()) {
                    cell.classList.add('disabled');
                } else {
                    cell.onclick = (function(day) {
                        return function() {
                            selectDay(day);
                        };
                    })(dayCount);
                    if (selectedDay === dayCount) {
                        cell.classList.add('selected');
                    }
                }
                row.appendChild(cell);
                dayCount++;
            } else {
                const cell = document.createElement('td');
                row.appendChild(cell);
            }
        }
        calendarBody.appendChild(row);
    }
}

function changeMonth(offset) {
    currentMonth += offset;
    if (currentMonth < 0) {
        currentMonth = 11;
        currentYear--;
    } else if (currentMonth > 11) {
        currentMonth = 0;
        currentYear++;
    }
    document.getElementById('monthSelect').value = currentMonth;
    document.getElementById('yearSelect').value = currentYear;
    updateCalendar();
}

function selectDay(day) {
    selectedDay = day;
    updateCalendar();
}

function selectTime(element) {
    const times = document.querySelectorAll('.times span');
    times.forEach(time => {
        time.style.backgroundColor = '#e0e7ff';
        time.style.color = 'black';
        time.classList.remove('selected');
    });
    element.style.backgroundColor = '#1a2a44';
    element.style.color = 'white';
    element.classList.add('selected');
    selectedTime = element.textContent;
}

function markAppointment() {
    const especialidade = document.getElementById('especialidade').value;
    const mensagem = document.getElementById('consultaMensagem');
    const button = document.querySelector('#unitDetails button');

    if (!selectedDay || !selectedTime || !especialidade || !selectedUnidadeId) {
        mensagem.innerText = 'Selecione data, horário, especialidade e unidade.';
        mensagem.className = 'error';
        return;
    }

    const data_hora = `${currentYear}-${String(currentMonth + 1).padStart(2, '0')}-${String(selectedDay).padStart(2, '0')} ${selectedTime}:00`;

    button.disabled = true;
    button.innerText = 'Marcando...';

    const formData = new FormData();
    formData.append('unidade_id', selectedUnidadeId);
    formData.append('especialidade_id', especialidade);
    formData.append('data_hora', data_hora);

    fetch('php/marcar_consulta.php', {
        method: 'POST',
        body: formData
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`Erro na requisição: ${response.status} ${response.statusText}`);
        }
        return response.text();
    })
    .then(data => {
        console.log('Resposta do servidor:', data); // Depuração
        mensagem.innerText = data;
        mensagem.className = data.includes('sucesso') ? 'success' : 'error';
        button.disabled = false;
        button.innerText = 'Marcar consulta';
        if (data.includes('sucesso')) {
            setTimeout(() => {
                closeUnitDetails();
                mensagem.innerText = '';
            }, 1000);
        }
    })
    .catch(error => {
        mensagem.innerText = 'Erro ao marcar consulta. Verifique o console para detalhes.';
        mensagem.className = 'error';
        button.disabled = false;
        button.innerText = 'Marcar consulta';
        console.error('Erro:', error);
    });
}