-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Tempo de geração: 10/06/2025 às 22:01
-- Versão do servidor: 8.2.0
-- Versão do PHP: 8.2.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `agiliza_sus`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `consultas`
--

DROP TABLE IF EXISTS `consultas`;
CREATE TABLE IF NOT EXISTS `consultas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `usuario_id` int NOT NULL,
  `unidade_id` int NOT NULL,
  `profissional_id` int DEFAULT NULL,
  `especialidade_id` int NOT NULL,
  `data_hora` datetime NOT NULL,
  `status` enum('Agendada','Confirmada','Realizada','Cancelada_Usuario','Cancelada_Profissional','Pendente_Confirmacao','Ausente') COLLATE utf8mb4_unicode_ci DEFAULT 'Pendente_Confirmacao',
  `observacoes_agendamento` text COLLATE utf8mb4_unicode_ci,
  `data_agendamento` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `usuario_id` (`usuario_id`),
  KEY `unidade_id` (`unidade_id`),
  KEY `profissional_id` (`profissional_id`),
  KEY `especialidade_id` (`especialidade_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `especialidades`
--

DROP TABLE IF EXISTS `especialidades`;
CREATE TABLE IF NOT EXISTS `especialidades` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nome` (`nome`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `especialidades`
--

INSERT INTO `especialidades` (`id`, `nome`) VALUES
(2, 'Cardiologia'),
(1, 'Clínica Geral'),
(6, 'Dermatologia'),
(5, 'Ginecologia'),
(3, 'Ortopedia'),
(4, 'Pediatria'),
(7, 'Psicologia');

-- --------------------------------------------------------

--
-- Estrutura para tabela `exames`
--

DROP TABLE IF EXISTS `exames`;
CREATE TABLE IF NOT EXISTS `exames` (
  `id` int NOT NULL AUTO_INCREMENT,
  `consulta_id` int DEFAULT NULL,
  `usuario_id` int NOT NULL,
  `profissional_solicitante_id` int DEFAULT NULL,
  `tipo_exame` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_solicitacao` date NOT NULL,
  `data_prevista_resultado` date DEFAULT NULL,
  `data_realizacao` date DEFAULT NULL,
  `local_realizacao` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('Solicitado','Agendado','Coletado','Em Analise','Resultado Disponivel','Cancelado','Entregue ao Paciente') COLLATE utf8mb4_unicode_ci DEFAULT 'Solicitado',
  `resultado_link` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `observacoes` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `consulta_id` (`consulta_id`),
  KEY `usuario_id` (`usuario_id`),
  KEY `profissional_solicitante_id` (`profissional_solicitante_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `guias_consulta`
--

DROP TABLE IF EXISTS `guias_consulta`;
CREATE TABLE IF NOT EXISTS `guias_consulta` (
  `id` int NOT NULL AUTO_INCREMENT,
  `consulta_id` int NOT NULL,
  `tipo_guia` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `conteudo_guia` text COLLATE utf8mb4_unicode_ci,
  `data_emissao` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `consulta_id` (`consulta_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `horarios_disponiveis`
--

DROP TABLE IF EXISTS `horarios_disponiveis`;
CREATE TABLE IF NOT EXISTS `horarios_disponiveis` (
  `id` int NOT NULL AUTO_INCREMENT,
  `unidade_id` int DEFAULT NULL,
  `profissional_id` int DEFAULT NULL,
  `especialidade_id` int DEFAULT NULL,
  `dia_semana` enum('0','1','2','3','4','5','6') COLLATE utf8mb4_unicode_ci NOT NULL,
  `hora_inicio` time NOT NULL,
  `hora_fim` time NOT NULL,
  `data_especifica` date DEFAULT NULL,
  `tipo_recorrencia` enum('Semanal','Quinzenal','Mensal','Unica') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `intervalo_slots_minutos` int DEFAULT '30',
  `ativo` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `unidade_id` (`unidade_id`),
  KEY `profissional_id` (`profissional_id`),
  KEY `especialidade_id` (`especialidade_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `notificacoes`
--

DROP TABLE IF EXISTS `notificacoes`;
CREATE TABLE IF NOT EXISTS `notificacoes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `usuario_id` int DEFAULT NULL,
  `profissional_id` int DEFAULT NULL,
  `titulo` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mensagem` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `link` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipo_notificacao` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_criacao` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `data_leitura` timestamp NULL DEFAULT NULL,
  `prioridade` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `usuario_id` (`usuario_id`),
  KEY `profissional_id` (`profissional_id`)
) ;

-- --------------------------------------------------------

--
-- Estrutura para tabela `profissionais`
--

DROP TABLE IF EXISTS `profissionais`;
CREATE TABLE IF NOT EXISTS `profissionais` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `especialidade_id` int DEFAULT NULL,
  `matricula` char(8) COLLATE utf8mb4_unicode_ci NOT NULL,
  `senha` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `unidade_id` int DEFAULT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telefone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ativo` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `matricula` (`matricula`),
  UNIQUE KEY `email` (`email`),
  KEY `especialidade_id` (`especialidade_id`),
  KEY `unidade_id` (`unidade_id`),
  KEY `idx_profissionais_email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `profissionais`
--

INSERT INTO `profissionais` (`id`, `nome`, `especialidade_id`, `matricula`, `senha`, `unidade_id`, `email`, `telefone`, `ativo`) VALUES
(1, 'Dr. João Médico', 1, '10203040', '$2y$10$HASH_PROF_JOAO_AQUI', 1, 'dr.joao@agilizasus.com', '(45) 99999-1001', 1);

-- --------------------------------------------------------

--
-- Estrutura para tabela `receitas_medicas`
--

DROP TABLE IF EXISTS `receitas_medicas`;
CREATE TABLE IF NOT EXISTS `receitas_medicas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `consulta_id` int DEFAULT NULL,
  `usuario_id` int NOT NULL,
  `profissional_id` int NOT NULL,
  `medicamento` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dosagem` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `frequencia` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `duracao_tratamento` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `instrucoes_adicionais` text COLLATE utf8mb4_unicode_ci,
  `data_emissao` date NOT NULL,
  `validade_receita` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `consulta_id` (`consulta_id`),
  KEY `usuario_id` (`usuario_id`),
  KEY `profissional_id` (`profissional_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `relatorios_medicos`
--

DROP TABLE IF EXISTS `relatorios_medicos`;
CREATE TABLE IF NOT EXISTS `relatorios_medicos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `consulta_id` int NOT NULL,
  `profissional_id` int NOT NULL,
  `sumario_consulta` text COLLATE utf8mb4_unicode_ci,
  `diagnostico_principal` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `diagnosticos_secundarios` text COLLATE utf8mb4_unicode_ci,
  `plano_tratamento` text COLLATE utf8mb4_unicode_ci,
  `recomendacoes` text COLLATE utf8mb4_unicode_ci,
  `precisa_jejum` tinyint(1) DEFAULT '0',
  `data_criacao` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `consulta_id` (`consulta_id`),
  KEY `profissional_id` (`profissional_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `unidades_saude`
--

DROP TABLE IF EXISTS `unidades_saude`;
CREATE TABLE IF NOT EXISTS `unidades_saude` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `logradouro` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numero` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `complemento` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bairro` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cidade` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `estado` char(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cep` varchar(9) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telefone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `horario_funcionamento` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `unidades_saude`
--

INSERT INTO `unidades_saude` (`id`, `nome`, `logradouro`, `numero`, `complemento`, `bairro`, `cidade`, `estado`, `cep`, `telefone`, `email`, `horario_funcionamento`) VALUES
(1, 'UBS Centro Feliz', 'Rua Principal', '100', NULL, 'Centro', 'Cidade Alegre', 'PR', '85000-001', '(45) 3220-1000', 'ubs.centro@cidadealegre.gov.br', 'Seg-Sex: 07h-19h'),
(2, 'Posto de Saúde Bairro Esperança', 'Avenida das Flores', '250', NULL, 'Esperança', 'Cidade Alegre', 'PR', '85000-002', '(45) 3220-2000', 'ps.esperanca@cidadealegre.gov.br', 'Seg-Sex: 08h-17h'),
(3, 'Clínica Bem Estar (Convênio)', 'Rua da Paz', '50', NULL, 'Jardim Tranquilo', 'Cidade Alegre', 'PR', '85000-003', '(45) 3220-3000', 'contato@clinicabemestar.com.br', 'Seg-Sab: 08h-20h');

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
CREATE TABLE IF NOT EXISTS `usuarios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cpf` varchar(14) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_nascimento` date NOT NULL,
  `telefone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `senha` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `logradouro` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numero` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `complemento` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bairro` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cidade` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `estado` char(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cep` varchar(9) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_cadastro` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cpf` (`cpf`),
  UNIQUE KEY `email` (`email`),
  KEY `idx_usuarios_email` (`email`),
  KEY `idx_usuarios_cpf` (`cpf`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `nome`, `cpf`, `data_nascimento`, `telefone`, `email`, `senha`, `logradouro`, `numero`, `complemento`, `bairro`, `cidade`, `estado`, `cep`, `data_cadastro`) VALUES
(1, 'Administrador do Sistema', '000.000.000-00', '1990-01-01', '(99) 99999-9999', 'admin@agilizasus.com', '$2y$10$SEU_HASH_AQUI_PARA_admin123', 'Rua da Administração', '01', NULL, 'Centro Admin', 'Cidade Agiliza', 'AS', '00000-000', '2025-06-09 22:13:54');

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `consultas`
--
ALTER TABLE `consultas`
  ADD CONSTRAINT `consultas_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `consultas_ibfk_2` FOREIGN KEY (`unidade_id`) REFERENCES `unidades_saude` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `consultas_ibfk_3` FOREIGN KEY (`profissional_id`) REFERENCES `profissionais` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `consultas_ibfk_4` FOREIGN KEY (`especialidade_id`) REFERENCES `especialidades` (`id`) ON DELETE RESTRICT;

--
-- Restrições para tabelas `exames`
--
ALTER TABLE `exames`
  ADD CONSTRAINT `exames_ibfk_1` FOREIGN KEY (`consulta_id`) REFERENCES `consultas` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `exames_ibfk_2` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `exames_ibfk_3` FOREIGN KEY (`profissional_solicitante_id`) REFERENCES `profissionais` (`id`) ON DELETE SET NULL;

--
-- Restrições para tabelas `guias_consulta`
--
ALTER TABLE `guias_consulta`
  ADD CONSTRAINT `guias_consulta_ibfk_1` FOREIGN KEY (`consulta_id`) REFERENCES `consultas` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `horarios_disponiveis`
--
ALTER TABLE `horarios_disponiveis`
  ADD CONSTRAINT `horarios_disponiveis_ibfk_1` FOREIGN KEY (`unidade_id`) REFERENCES `unidades_saude` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `horarios_disponiveis_ibfk_2` FOREIGN KEY (`profissional_id`) REFERENCES `profissionais` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `horarios_disponiveis_ibfk_3` FOREIGN KEY (`especialidade_id`) REFERENCES `especialidades` (`id`) ON DELETE SET NULL;

--
-- Restrições para tabelas `notificacoes`
--
ALTER TABLE `notificacoes`
  ADD CONSTRAINT `notificacoes_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `notificacoes_ibfk_2` FOREIGN KEY (`profissional_id`) REFERENCES `profissionais` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `profissionais`
--
ALTER TABLE `profissionais`
  ADD CONSTRAINT `profissionais_ibfk_1` FOREIGN KEY (`especialidade_id`) REFERENCES `especialidades` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `profissionais_ibfk_2` FOREIGN KEY (`unidade_id`) REFERENCES `unidades_saude` (`id`) ON DELETE SET NULL;

--
-- Restrições para tabelas `receitas_medicas`
--
ALTER TABLE `receitas_medicas`
  ADD CONSTRAINT `receitas_medicas_ibfk_1` FOREIGN KEY (`consulta_id`) REFERENCES `consultas` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `receitas_medicas_ibfk_2` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `receitas_medicas_ibfk_3` FOREIGN KEY (`profissional_id`) REFERENCES `profissionais` (`id`) ON DELETE RESTRICT;

--
-- Restrições para tabelas `relatorios_medicos`
--
ALTER TABLE `relatorios_medicos`
  ADD CONSTRAINT `relatorios_medicos_ibfk_1` FOREIGN KEY (`consulta_id`) REFERENCES `consultas` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `relatorios_medicos_ibfk_2` FOREIGN KEY (`profissional_id`) REFERENCES `profissionais` (`id`) ON DELETE RESTRICT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
